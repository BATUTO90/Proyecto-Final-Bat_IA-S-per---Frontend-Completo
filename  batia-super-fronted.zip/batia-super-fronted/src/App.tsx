import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import ChatPage from './pages/ChatPage';
import CodePage from './pages/CodePage';
import ImagePage from './pages/ImagePage';
import PromptCreatorPage from './pages/PromptCreatorPage';
import ImageToPromptPage from './pages/ImageToPromptPage';
import PromptOptimizerPage from './pages/PromptOptimizerPage';
import './styles/globals.css';

const App: React.FC = () => {
  return (
    <Router>
      <div className="app">
        <Navbar />
        <main className="main-content">
          <Routes>
            <Route path="/" element={<ChatPage />} />
            <Route path="/code" element={<CodePage />} />
            <Route path="/images" element={<ImagePage />} />
            <Route path="/prompt-creator" element={<PromptCreatorPage />} />
            <Route path="/image-to-prompt" element={<ImageToPromptPage />} />
            <Route path="/prompt-optimizer" element={<PromptOptimizerPage />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;