import React from 'react';

interface AspectRatioContainerProps {
  children: React.ReactNode;
  className?: string;
}

const AspectRatioContainer: React.FC<AspectRatioContainerProps> = ({ 
  children, 
  className = '' 
}) => {
  return (
    <div className={`aspect-ratio-container ${className}`}>
      <div className="aspect-ratio-content">
        {children}
      </div>
    </div>
  );
};

export default AspectRatioContainer;