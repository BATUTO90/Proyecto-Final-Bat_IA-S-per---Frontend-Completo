import React from 'react';
import { Download, Copy, Check } from 'lucide-react';

interface DownloadButtonProps {
  content: string | Blob;
  type: 'text' | 'image';
  filename: string;
  mimeType?: string;
}

const DownloadButton: React.FC<DownloadButtonProps> = ({ 
  content, 
  type, 
  filename, 
  mimeType = type === 'image' ? 'image/png' : 'text/plain' 
}) => {
  const [copied, setCopied] = React.useState(false);

  const handleDownload = () => {
    if (type === 'text') {
      const blob = new Blob([content as string], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } else {
      const url = URL.createObjectURL(content as Blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const handleCopy = async () => {
    if (type === 'text') {
      await navigator.clipboard.writeText(content as string);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
      <button 
        onClick={handleDownload} 
        className="btn btn-primary"
        style={{ color: 'inherit' }}
      >
        <Download size={16} />
        Descargar
      </button>
      
      {type === 'text' && (
        <button 
          onClick={handleCopy} 
          className="btn"
          style={{ 
            borderColor: copied ? '#3fb950' : 'var(--border)',
            color: copied ? '#3fb950' : 'var(--text-primary)'
          }}
        >
          {copied ? <Check size={16} /> : <Copy size={16} />}
          {copied ? 'Copiado!' : 'Copiar'}
        </button>
      )}
    </div>
  );
};

export default DownloadButton;