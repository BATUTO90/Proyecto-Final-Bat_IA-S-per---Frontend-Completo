import React from 'react';
import { HYPERREALISM_KEYWORDS } from '../utils/promptUtils';

const HyperRealismGuide: React.FC = () => {
  return (
    <div className="keywords-guide">
      <h4>🎨 Palabras Clave para Hiperrealismo Perfecto</h4>
      <div className="keywords-list">
        {HYPERREALISM_KEYWORDS.slice(0, 15).map((keyword, index) => (
          <span key={index} className="keyword-tag">{keyword}</span>
        ))}
      </div>
    </div>
  );
};

export default HyperRealismGuide;