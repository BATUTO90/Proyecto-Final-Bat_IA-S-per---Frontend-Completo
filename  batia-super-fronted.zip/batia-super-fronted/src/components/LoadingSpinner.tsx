import React from 'react';

interface LoadingSpinnerProps {
  size?: 'small' | 'medium' | 'large';
  message?: string;
  accentColor?: string;
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ 
  size = 'medium', 
  message = 'Cargando...',
  accentColor = 'var(--chat-accent)'
}) => {
  const sizeMap = {
    small: '1rem',
    medium: '2rem',
    large: '3rem'
  };

  return (
    <div className="loading">
      <div 
        className="spinner"
        style={{
          width: sizeMap[size],
          height: sizeMap[size],
          border: `3px solid rgba(255, 255, 255, 0.1)`,
          borderTop: `3px solid ${accentColor}`,
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}
      />
      {message && (
        <span style={{ marginLeft: '0.75rem', color: 'var(--text-secondary)' }}>
          {message}
        </span>
      )}
    </div>
  );
};

export default LoadingSpinner;