import React from 'react';
import { Settings } from 'lucide-react';

interface ModelSelectorProps {
  selectedModel: string;
  onModelChange: (model: string) => void;
  models: Array<{ value: string; label: string }>;
  accentColor?: string;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ 
  selectedModel, 
  onModelChange, 
  models,
  accentColor = 'var(--chat-accent)'
}) => {
  return (
    <div style={{ marginBottom: '1rem' }}>
      <label style={{ 
        display: 'flex', 
        alignItems: 'center', 
        gap: '0.5rem', 
        marginBottom: '0.5rem',
        color: 'var(--text-secondary)',
        fontSize: '0.9rem'
      }}>
        <Settings size={16} />
        Seleccionar Modelo:
      </label>
      <select 
        value={selectedModel} 
        onChange={(e) => onModelChange(e.target.value)}
        style={{ 
          width: '100%',
          background: 'var(--bg-tertiary)', 
          color: 'var(--text-primary)',
          border: `1px solid ${accentColor}`,
          borderRadius: '6px',
          padding: '0.75rem',
          fontSize: '1rem',
          cursor: 'pointer'
        }}
      >
        {models.map((model) => (
          <option key={model.value} value={model.value}>
            {model.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default ModelSelector;