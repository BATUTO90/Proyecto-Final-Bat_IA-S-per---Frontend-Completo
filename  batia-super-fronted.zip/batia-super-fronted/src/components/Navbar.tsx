import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  MessageSquare, 
  Code, 
  Image, 
  Wand2, 
  Upload, 
  Zap 
} from 'lucide-react';

const Navbar: React.FC = () => {
  const location = useLocation();
  
  const navItems = [
    { path: '/', label: 'Chat', icon: MessageSquare, color: 'var(--chat-accent)' },
    { path: '/code', label: 'Generar Código', icon: Code, color: 'var(--code-accent)' },
    { path: '/images', label: 'Generar Imágenes', icon: Image, color: 'var(--image-accent)' },
    { path: '/prompt-creator', label: 'Creador de Prompts', icon: Wand2, color: 'var(--prompt-creator-accent)' },
    { path: '/image-to-prompt', label: 'Imagen a Prompt', icon: Upload, color: 'var(--image-to-prompt-accent)' },
    { path: '/prompt-optimizer', label: 'Optimizador', icon: Zap, color: 'var(--optimizer-accent)' },
  ];

  return (
    <nav className="navbar">
      <div className="nav-brand">Bat_IA Súper</div>
      <ul className="nav-links">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <li key={item.path}>
              <Link 
                to={item.path} 
                className={isActive ? 'active' : ''}
                style={isActive ? { color: item.color, borderLeftColor: item.color } : {}}
              >
                <Icon size={18} />
                {item.label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
};

export default Navbar;