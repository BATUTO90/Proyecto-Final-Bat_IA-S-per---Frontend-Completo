import React, { useState } from 'react';
import { Send, User, Bot } from 'lucide-react';
import { chat, ChatMessage } from '../services/enhancedApi';
import DownloadButton from '../components/DownloadButton';

const ChatPage: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState('meta-llama/Llama-3.1-8B-Instruct');

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await chat(newMessages, model);
      const assistantMessage: ChatMessage = { role: 'assistant', content: response };
      setMessages([...newMessages, assistantMessage]);
    } catch (error) {
      console.error('Error en el chat:', error);
      const errorMessage: ChatMessage = { 
        role: 'assistant', 
        content: 'Error al conectar con el servicio. Por favor intenta nuevamente.' 
      };
      setMessages([...newMessages, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const chatText = messages.map(m => `${m.role}: ${m.content}`).join('\n\n');

  return (
    <div className="page chat-page">
      <div className="page-header">
        <h1 style={{ color: 'var(--chat-accent)' }}>Chat Inteligente</h1>
        <p>Conversa con los modelos de IA más avanzados</p>
      </div>

      <div className="input-section">
        <select 
          value={model} 
          onChange={(e) => setModel(e.target.value)}
          style={{ 
            background: 'var(--bg-tertiary)', 
            color: 'var(--text-primary)',
            border: '1px solid var(--border)',
            borderRadius: '6px',
            padding: '0.5rem',
            marginBottom: '1rem'
          }}
        >
          <option value="meta-llama/Llama-3.1-8B-Instruct">Llama 3.1 8B</option>
          <option value="mistralai/Mistral-7B-Instruct-v0.2">Mistral 7B</option>
        </select>
        
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Escribe tu mensaje..."
            onKeyPress={(e) => e.key === 'Enter' && !e.shiftKey && handleSend()}
            className="textarea"
            rows={3}
          />
          <button 
            onClick={handleSend} 
            disabled={loading || !input.trim()}
            className="btn btn-primary"
            style={{ color: 'var(--chat-accent)', alignSelf: 'flex-end' }}
          >
            <Send size={16} />
          </button>
        </div>
      </div>

      <div className="output-section">
        <div style={{ minHeight: '400px', marginBottom: '1rem' }}>
          {messages.map((message, index) => (
            <div key={index} style={{ 
              marginBottom: '1rem', 
              padding: '1rem', 
              background: message.role === 'user' ? 'var(--bg-tertiary)' : 'transparent',
              borderRadius: '8px',
              border: message.role === 'user' ? '1px solid var(--border)' : 'none'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                {message.role === 'user' ? <User size={16} /> : <Bot size={16} />}
                <strong style={{ color: message.role === 'user' ? 'var(--chat-accent)' : 'var(--text-primary)' }}>
                  {message.role === 'user' ? 'Tú' : 'Bat_IA'}
                </strong>
              </div>
              <div style={{ whiteSpace: 'pre-wrap' }}>{message.content}</div>
            </div>
          ))}
          {loading && (
            <div className="loading">
              <div className="spinner">⚡</div>
              <span style={{ marginLeft: '0.5rem' }}>Bat_IA está pensando...</span>
            </div>
          )}
        </div>

        {messages.length > 0 && (
          <DownloadButton
            content={chatText}
            type="text"
            filename="conversacion_batia.txt"
          />
        )}
      </div>
    </div>
  );
};

export default ChatPage;