import React, { useState } from 'react';
import { Code, Copy, Check } from 'lucide-react';
import { generateCode, ChatMessage } from '../services/enhancedApi';
import DownloadButton from '../components/DownloadButton';

const CodePage: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState('deepseek-coder');
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!input.trim()) return;

    const userMessage: ChatMessage = { role: 'user', content: input };
    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const response = await generateCode(newMessages, model);
      const assistantMessage: ChatMessage = { role: 'assistant', content: response };
      setMessages([...newMessages, assistantMessage]);
    } catch (error) {
      console.error('Error generating code:', error);
      const errorMessage: ChatMessage = { 
        role: 'assistant', 
        content: 'Error al generar el código. Por favor intenta nuevamente.' 
      };
      setMessages([...newMessages, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const lastCodeResponse = messages.filter(m => m.role === 'assistant').pop()?.content || '';

  const handleCopyCode = async () => {
    await navigator.clipboard.writeText(lastCodeResponse);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="page code-page">
      <div className="page-header">
        <h1 style={{ color: 'var(--code-accent)' }}>Generador de Código</h1>
        <p>Obtén ayuda con programación usando DeepSeek Coder y Mistral</p>
      </div>

      <div className="input-section">
        <select 
          value={model} 
          onChange={(e) => setModel(e.target.value)}
          style={{ 
            background: 'var(--bg-tertiary)', 
            color: 'var(--text-primary)',
            border: '1px solid var(--border)',
            borderRadius: '6px',
            padding: '0.5rem',
            marginBottom: '1rem'
          }}
        >
          <option value="deepseek-coder">DeepSeek Coder</option>
          <option value="mistralai/Mistral-7B-Instruct-v0.2">Mistral 7B</option>
        </select>
        
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Describe el código que necesitas o pega tu código para mejoras..."
            className="textarea"
            rows={3}
          />
          <button 
            onClick={handleGenerate} 
            disabled={loading || !input.trim()}
            className="btn btn-primary"
            style={{ color: 'var(--code-accent)', alignSelf: 'flex-end' }}
          >
            <Code size={16} />
          </button>
        </div>
      </div>

      <div className="output-section">
        <div style={{ minHeight: '300px', marginBottom: '1rem' }}>
          {messages.map((message, index) => (
            <div key={index} style={{ 
              marginBottom: '1rem', 
              padding: '1rem', 
              background: message.role === 'user' ? 'var(--bg-tertiary)' : 'transparent',
              borderRadius: '8px',
              border: message.role === 'user' ? '1px solid var(--border)' : 'none'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
                <Code size={16} />
                <strong style={{ color: message.role === 'user' ? 'var(--code-accent)' : 'var(--text-primary)' }}>
                  {message.role === 'user' ? 'Tu solicitud' : 'Código generado'}
                </strong>
              </div>
              <div style={{ 
                whiteSpace: 'pre-wrap',
                fontFamily: message.role === 'assistant' ? 'Monaco, Menlo, monospace' : 'inherit',
                background: message.role === 'assistant' ? 'var(--bg-tertiary)' : 'transparent',
                padding: message.role === 'assistant' ? '1rem' : '0',
                borderRadius: message.role === 'assistant' ? '6px' : '0',
                fontSize: message.role === 'assistant' ? '0.9rem' : '1rem'
              }}>
                {message.content}
              </div>
            </div>
          ))}
          {loading && (
            <div className="loading">
              <div className="spinner">⚡</div>
              <span style={{ marginLeft: '0.5rem' }}>Generando código...</span>
            </div>
          )}
        </div>

        {lastCodeResponse && (
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button 
              onClick={handleCopyCode} 
              className="btn"
              style={{ 
                borderColor: copied ? '#3fb950' : 'var(--border)',
                color: copied ? '#3fb950' : 'var(--text-primary)'
              }}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? 'Copiado!' : 'Copiar Código'}
            </button>
            
            <DownloadButton
              content={lastCodeResponse}
              type="text"
              filename="codigo_generado.py"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default CodePage;