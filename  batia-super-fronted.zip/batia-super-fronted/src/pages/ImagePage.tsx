import React, { useState } from 'react';
import { Generate, Download } from 'lucide-react';
import { generateImage } from '../services/enhancedApi';
import AspectRatioContainer from '../components/AspectRatioContainer';
import DownloadButton from '../components/DownloadButton';
import HyperRealismGuide from '../components/HyperRealismGuide';

const ImagePage: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [generatedImage, setGeneratedImage] = useState<Blob | null>(null);
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string>('');

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setLoading(true);
    try {
      const response = await generateImage(prompt);
      
      // Si la respuesta es una URL, la convertimos a Blob
      if (response.image_url) {
        const blobResponse = await fetch(response.image_url);
        const blob = await blobResponse.blob();
        setGeneratedImage(blob);
        setImageUrl(URL.createObjectURL(blob));
      } else if (response.image_data) {
        // Si es base64
        const byteCharacters = atob(response.image_data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
        const blob = new Blob([byteArray], { type: 'image/png' });
        setGeneratedImage(blob);
        setImageUrl(URL.createObjectURL(blob));
      }
    } catch (error) {
      console.error('Error generating image:', error);
      alert('Error al generar la imagen. Por favor intenta nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page image-page">
      <div className="page-header">
        <h1 style={{ color: 'var(--image-accent)' }}>Generador de Imágenes Hiperrealistas</h1>
        <p>Genera imágenes en formato 9:16 perfecto para hiperrealismo</p>
      </div>

      <div className="input-section">
        <textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe la imagen que deseas generar en formato 9:16 cuerpo completo..."
          className="textarea"
          rows={4}
        />
        
        <HyperRealismGuide />
        
        <button 
          onClick={handleGenerate} 
          disabled={loading || !prompt.trim()}
          className="btn btn-primary"
          style={{ color: 'var(--image-accent)', marginTop: '1rem' }}
        >
          <Generate size={16} />
          {loading ? 'Generando...' : 'Generar Imagen'}
        </button>
      </div>

      <div className="output-section">
        <AspectRatioContainer>
          {imageUrl ? (
            <img src={imageUrl} alt="Generated" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          ) : (
            <div style={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center', 
              height: '100%',
              color: 'var(--text-secondary)',
              textAlign: 'center',
              padding: '2rem'
            }}>
              {loading ? (
                <div className="loading">
                  <div className="spinner">🎨</div>
                  <span style={{ marginLeft: '0.5rem' }}>Generando imagen hiperrealista...</span>
                </div>
              ) : (
                'La imagen generada aparecerá aquí en formato 9:16'
              )}
            </div>
          )}
        </AspectRatioContainer>

        {generatedImage && (
          <DownloadButton
            content={generatedImage}
            type="image"
            filename="imagen_hiperrealista.png"
          />
        )}
      </div>
    </div>
  );
};

export default ImagePage;