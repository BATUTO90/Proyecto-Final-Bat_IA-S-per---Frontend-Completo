import React, { useState } from 'react';
import { Upload, Image as ImageIcon } from 'lucide-react';
import { imageToPrompt } from '../services/enhancedApi';
import DownloadButton from '../components/DownloadButton';

const ImageToPromptPage: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [generatedPrompt, setGeneratedPrompt] = useState('');
  const [loading, setLoading] = useState(false);

  const handleImageSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      setImagePreview(URL.createObjectURL(file));
      setGeneratedPrompt('');
    }
  };

  const handleGeneratePrompt = async () => {
    if (!selectedImage) return;

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('image', selectedImage);
      
      const response = await imageToPrompt(formData);
      setGeneratedPrompt(response.prompt || response.description);
    } catch (error) {
      console.error('Error generating prompt:', error);
      alert('Error al generar el prompt. Por favor intenta con otra imagen.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page image-to-prompt-page">
      <div className="page-header">
        <h1 style={{ color: 'var(--image-to-prompt-accent)' }}>Imagen a Prompt</h1>
        <p>Sube cualquier imagen y genera automáticamente un prompt descriptivo en inglés</p>
      </div>

      <div className="input-section">
        <div style={{ 
          border: '2px dashed var(--border)', 
          borderRadius: '8px',
          padding: '2rem',
          textAlign: 'center',
          cursor: 'pointer',
          marginBottom: '1rem'
        }}>
          <input
            type="file"
            accept="image/*"
            onChange={handleImageSelect}
            style={{ display: 'none' }}
            id="image-upload"
          />
          <label htmlFor="image-upload" style={{ cursor: 'pointer' }}>
            <Upload size={48} style={{ color: 'var(--text-secondary)', marginBottom: '1rem' }} />
            <div style={{ color: 'var(--text-secondary)' }}>
              {selectedImage ? 'Imagen seleccionada: ' + selectedImage.name : 'Haz clic para subir una imagen'}
            </div>
          </label>
        </div>

        {imagePreview && (
          <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
            <img 
              src={imagePreview} 
              alt="Preview" 
              style={{ 
                maxWidth: '300px', 
                maxHeight: '300px', 
                borderRadius: '8px',
                border: '1px solid var(--border)'
              }} 
            />
          </div>
        )}

        <button 
          onClick={handleGeneratePrompt} 
          disabled={!selectedImage || loading}
          className="btn btn-primary"
          style={{ color: 'var(--image-to-prompt-accent)' }}
        >
          <ImageIcon size={16} />
          {loading ? 'Generando Prompt...' : 'Generar Prompt desde Imagen'}
        </button>
      </div>

      {generatedPrompt && (
        <div className="output-section">
          <h4 style={{ marginBottom: '1rem' }}>📝 Prompt Generado (Inglés):</h4>
          <div style={{ 
            background: 'var(--bg-tertiary)', 
            padding: '1rem', 
            borderRadius: '6px',
            border: '1px solid var(--border)',
            marginBottom: '1rem',
            whiteSpace: 'pre-wrap',
            fontFamily: 'monospace',
            fontSize: '0.9rem'
          }}>
            {generatedPrompt}
          </div>
          
          <DownloadButton
            content={generatedPrompt}
            type="text"
            filename="prompt_desde_imagen.txt"
          />
        </div>
      )}
    </div>
  );
};

export default ImageToPromptPage;