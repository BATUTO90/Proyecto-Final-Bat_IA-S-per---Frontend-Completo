import React, { useState } from 'react';
import { Wand2, Copy, Check } from 'lucide-react';
import { enhancePrompt } from '../utils/promptUtils';
import HyperRealismGuide from '../components/HyperRealismGuide';
import DownloadButton from '../components/DownloadButton';

const PromptCreatorPage: React.FC = () => {
  const [simplePrompt, setSimplePrompt] = useState('');
  const [enhancedPrompt, setEnhancedPrompt] = useState('');
  const [copied, setCopied] = useState(false);

  const handleEnhance = () => {
    if (!simplePrompt.trim()) return;
    const enhanced = enhancePrompt(simplePrompt);
    setEnhancedPrompt(enhanced);
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(enhancedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="page prompt-creator-page">
      <div className="page-header">
        <h1 style={{ color: 'var(--prompt-creator-accent)' }}>Creador de Prompts Hiperrealistas</h1>
        <p>Transforma tu idea simple en un prompt técnico profesional listo para usar</p>
      </div>

      <div className="input-section">
        <textarea
          value={simplePrompt}
          onChange={(e) => setSimplePrompt(e.target.value)}
          placeholder="Ej: una mujer con cabello castaño en un bosque al atardecer"
          className="textarea"
          rows={3}
        />
        
        <button 
          onClick={handleEnhance} 
          disabled={!simplePrompt.trim()}
          className="btn btn-primary"
          style={{ color: 'var(--prompt-creator-accent)', marginTop: '1rem' }}
        >
          <Wand2 size={16} />
          Perfeccionar Prompt
        </button>
      </div>

      <HyperRealismGuide />

      {enhancedPrompt && (
        <div className="output-section">
          <h4 style={{ marginBottom: '1rem' }}>🎯 Prompt Perfeccionado (Inglés Técnico):</h4>
          <div style={{ 
            background: 'var(--bg-tertiary)', 
            padding: '1rem', 
            borderRadius: '6px',
            border: '1px solid var(--border)',
            marginBottom: '1rem',
            whiteSpace: 'pre-wrap',
            fontFamily: 'monospace',
            fontSize: '0.9rem'
          }}>
            {enhancedPrompt}
          </div>
          
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button 
              onClick={handleCopy} 
              className="btn"
              style={{ 
                borderColor: copied ? '#3fb950' : 'var(--border)',
                color: copied ? '#3fb950' : 'var(--text-primary)'
              }}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? 'Copiado!' : 'Copiar Prompt'}
            </button>
            
            <DownloadButton
              content={enhancedPrompt}
              type="text"
              filename="prompt_hiperrealista.txt"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default PromptCreatorPage;