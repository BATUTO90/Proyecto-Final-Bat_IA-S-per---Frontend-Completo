import React, { useState } from 'react';
import { Zap, Scissors, Expand, Copy, Check } from 'lucide-react';
import { shortenPrompt, expandPrompt } from '../utils/promptUtils';
import DownloadButton from '../components/DownloadButton';

const PromptOptimizerPage: React.FC = () => {
  const [originalPrompt, setOriginalPrompt] = useState('');
  const [optimizedPrompt, setOptimizedPrompt] = useState('');
  const [optimizationMode, setOptimizationMode] = useState<'shorten' | 'expand'>('expand');
  const [copied, setCopied] = useState(false);

  const handleOptimize = () => {
    if (!originalPrompt.trim()) return;

    if (optimizationMode === 'shorten') {
      setOptimizedPrompt(shortenPrompt(originalPrompt));
    } else {
      setOptimizedPrompt(expandPrompt(originalPrompt));
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(optimizedPrompt);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="page prompt-optimizer-page">
      <div className="page-header">
        <h1 style={{ color: 'var(--optimizer-accent)' }}>Optimizador de Prompts</h1>
        <p>Perfecciona tus prompts: acorta los muy largos o expande los muy cortos para hiperrealismo</p>
      </div>

      <div className="input-section">
        <textarea
          value={originalPrompt}
          onChange={(e) => setOriginalPrompt(e.target.value)}
          placeholder="Pega tu prompt aquí para optimizarlo..."
          className="textarea"
          rows={4}
        />
        
        <div style={{ display: 'flex', gap: '1rem', margin: '1rem 0' }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
            <input
              type="radio"
              value="expand"
              checked={optimizationMode === 'expand'}
              onChange={(e) => setOptimizationMode(e.target.value as 'shorten' | 'expand')}
            />
            <Expand size={16} />
            Expandir (para prompts cortos)
          </label>
          
          <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', cursor: 'pointer' }}>
            <input
              type="radio"
              value="shorten"
              checked={optimizationMode === 'shorten'}
              onChange={(e) => setOptimizationMode(e.target.value as 'shorten' | 'expand')}
            />
            <Scissors size={16} />
            Acortar (para prompts largos)
          </label>
        </div>

        <button 
          onClick={handleOptimize} 
          disabled={!originalPrompt.trim()}
          className="btn btn-primary"
          style={{ color: 'var(--optimizer-accent)' }}
        >
          <Zap size={16} />
          Optimizar Prompt
        </button>
      </div>

      {optimizedPrompt && (
        <div className="output-section">
          <h4 style={{ marginBottom: '1rem' }}>
            {optimizationMode === 'expand' ? '🚀 Prompt Expandido' : '✂️ Prompt Optimizado'}
          </h4>
          
          <div style={{ marginBottom: '1rem' }}>
            <strong>Original ({originalPrompt.split(' ').length} palabras):</strong>
            <div style={{ 
              background: 'var(--bg-tertiary)', 
              padding: '0.75rem', 
              borderRadius: '6px',
              marginTop: '0.5rem',
              fontSize: '0.9rem',
              opacity: 0.8
            }}>
              {originalPrompt}
            </div>
          </div>

          <div style={{ marginBottom: '1rem' }}>
            <strong>Optimizado ({optimizedPrompt.split(' ').length} palabras):</strong>
            <div style={{ 
              background: 'var(--bg-tertiary)', 
              padding: '1rem', 
              borderRadius: '6px',
              border: '1px solid var(--border)',
              marginTop: '0.5rem',
              whiteSpace: 'pre-wrap',
              fontFamily: 'monospace',
              fontSize: '0.9rem'
            }}>
              {optimizedPrompt}
            </div>
          </div>
          
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
            <button 
              onClick={handleCopy} 
              className="btn"
              style={{ 
                borderColor: copied ? '#3fb950' : 'var(--border)',
                color: copied ? '#3fb950' : 'var(--text-primary)'
              }}
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
              {copied ? 'Copiado!' : 'Copiar Prompt'}
            </button>
            
            <DownloadButton
              content={optimizedPrompt}
              type="text"
              filename="prompt_optimizado.txt"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default PromptOptimizerPage;