import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8000',
});

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ImageGenerationResponse {
  image_url: string;
  image_data?: string;
}

// APIs principales existentes
export const chat = (messages: ChatMessage[], model: string) =>
  api.post('/chat', { messages, model }).then((r) => r.data.response);

export const generateCode = (messages: ChatMessage[], model: string) =>
  api.post('/codigo', { messages, model }).then((r) => r.data.response);

export const generateImage = (prompt: string) =>
  api.post('/imagen', { prompt }).then((r) => r.data);

// Nuevas APIs extendidas
export const imageToPrompt = (formData: FormData) =>
  api.post('/image/to-prompt', formData).then((r) => r.data);

export const createEnhancedPrompt = (simplePrompt: string) =>
  api.post('/prompt/enhance', { prompt: simplePrompt }).then((r) => r.data);

export const optimizePrompt = (prompt: string, mode: 'shorten' | 'expand') =>
  api.post('/prompt/optimize', { prompt, mode }).then((r) => r.data);

export const checkBackendStatus = () =>
  api.get('/').then((r) => r.data);

export default api;