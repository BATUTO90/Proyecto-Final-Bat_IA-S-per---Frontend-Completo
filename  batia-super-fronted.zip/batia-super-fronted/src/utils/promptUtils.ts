// Palabras clave técnicas para hiperrealismo
export const HYPERREALISM_KEYWORDS = [
  "hyperrealistic human portrait",
  "9:16 aspect ratio",
  "full body composition",
  "cinematic lighting",
  "16K resolution",
  "Unreal Engine 5 render",
  "Octane render",
  "detailed skin texture",
  "natural pores",
  "subtle imperfections",
  "ray tracing",
  "professional photography",
  "masterpiece",
  "photorealistic",
  "detailed eyes",
  "natural skin texture",
  "microexpressions",
  "subsurface scattering",
  "8K textures",
  "film grain",
  "shallow depth of field",
  "Canon EOS R5",
  "85mm f/1.2",
  "studio lighting",
  "Rembrandt lighting",
  "volumetric lighting",
  "skin details",
  "hair strands",
  "moist eyes",
  "natural pose",
  "environment integration"
];

export const enhancePrompt = (userPrompt: string): string => {
  const baseKeywords = "hyperrealistic human portrait, 9:16 aspect ratio, full body, cinematic lighting, 16K resolution, Unreal Engine 5, detailed skin texture, natural pores, subtle imperfections, ray tracing, professional photography";
  
  return `${userPrompt}, ${baseKeywords}, masterpiece, photorealistic, detailed eyes, natural skin texture, film grain, shallow depth of field, studio quality`;
};

export const shortenPrompt = (prompt: string): string => {
  // Elimina redundancias y acorta manteniendo esencia
  const words = prompt.split(',');
  const uniqueWords = [...new Set(words.map(w => w.trim()))];
  return uniqueWords.slice(0, 15).join(', ');
};

export const expandPrompt = (prompt: string): string => {
  // Añade keywords técnicas faltantes
  const existingKeywords = prompt.toLowerCase();
  const missingKeywords = HYPERREALISM_KEYWORDS.filter(keyword => 
    !existingKeywords.includes(keyword.toLowerCase())
  ).slice(0, 10);
  
  return `${prompt}, ${missingKeywords.join(', ')}`;
};